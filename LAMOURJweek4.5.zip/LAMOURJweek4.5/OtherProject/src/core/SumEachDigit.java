package core;

public class SumEachDigit {


    public static int getNumberSum(int number) {
        int sum = 0;

        if (number == 0) {
            return sum;
        } else {
            while (number > 0) {
                sum += (number % 10);
                number = number / 10;
            }
            return sum;
        }
    }
}
