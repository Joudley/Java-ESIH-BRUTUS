package core;

import java.util.*;
import java.util.Map.Entry;
public class SortMapValue {
    public static void mapByValue(){
        Scanner sc = new Scanner(System.in);
        Map<String, Integer> map = new HashMap<String, Integer>();
        System.out.println("Combien de notes voulez vous entrer?");
        int vf = sc.nextInt();
        for (int i = 0; i < vf; i++) {
            System.out.println("Entrer le nom et la note");
            String nom = sc.next();
            int valeur = sc.nextInt();
            map.put(nom,valeur);
        }
        Set<Entry<String, Integer>> set = map.entrySet();
        List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(set);
        Collections.sort( list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
            {
                return (o2.getValue()).compareTo( o1.getValue() );
            }
        } );
        for(Map.Entry<String, Integer> entry:list){
            System.out.println(entry.getKey()+" ==== "+entry.getValue());
        }
    }
}
