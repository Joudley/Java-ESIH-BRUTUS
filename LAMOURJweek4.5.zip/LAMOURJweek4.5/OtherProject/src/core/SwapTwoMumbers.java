package core;

public class SwapTwoMumbers {
    public static void swapToNumber(int x,int y){
        System.out.println("Avant permutation:");
        System.out.println("La valeur de x: "+x);
        System.out.println("La valeur de y: "+y);
        x = x+y;
        y=x-y;
        x=x-y;
        System.out.println("Apres permutation:");
        System.out.println("La valeur de x: "+x);
        System.out.println("La valeur de y: "+y);
    }

}
