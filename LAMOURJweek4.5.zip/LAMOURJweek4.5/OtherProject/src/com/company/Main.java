package com.company;

import core.*;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ce programme vous permet d'effectuer plusiers sortes de choses ");
        System.out.println("---------------------------------------------------");
        System.out.println("Faites choix de ce que vous voudriez :");
        System.out.println("---------------------------------------------------");
        System.out.println("       1- To find out duplicate characters in a string");
        System.out.println("---------------------------------------------------");
        System.out.println("       2- To find top two maximum numbers in a array");
        System.out.println("---------------------------------------------------");
        System.out.println("       3- To sort a map by value");
        System.out.println("---------------------------------------------------");
        System.out.println("       4- To find common elements between two arrays");
        System.out.println("---------------------------------------------------");
        System.out.println("       5- To swap two numbers without using temporary variable?");
        System.out.println("---------------------------------------------------");
        System.out.println("       6- To print fibonacci series");
        System.out.println("---------------------------------------------------");
        System.out.println("       7- Write a program to find sum of each digit in the given number using recursion");
        System.out.println("---------------------------------------------------");
        System.out.println("       8- To check the given number is a prime number or not?");
        System.out.println("---------------------------------------------------");
        System.out.println("       9- To find the given number is a Armstrong number or not?");
        System.out.println("---------------------------------------------------");
        System.out.println("       10- To convert binary to decimal number");
        int choice = sc.nextInt();
        switch (choice) {

            case 1 -> {
                System.out.println("Entrer une chaine de caractere:");
                String dup = sc.next();
                System.out.println("Les caracteres qui apparaient plusieurs fois sont:");
                DuplicateChar.findDuplicateChars(dup);
            }


            case 2 -> {
                System.out.println("Combien d'elements contient votre tableau:");
                int num = sc.nextInt();
                int[] tab1 = new int[num];
                System.out.println("Entrer les nombres:");
                for (int i = 0; i < num; i++) {
                    tab1[i] = sc.nextInt();
                }
                TwoMaxNumber.printTwoMaxNumbers(tab1);
            }

            //
            case 3->{
                SortMapValue.mapByValue();
            }

            case 4->{
                System.out.println("Combien d'elements contient votre le premier tableau:" );
                int nbr = sc.nextInt();
                int [] tab1 = new int[nbr];
                System.out.println("Entrer les nombres:");
                for (int i = 0; i < nbr; i++) {
                    tab1 [i] = sc.nextInt();
                }

                System.out.println("Combien d'elements contient votre deuxieme tableau:" );
                int nb = sc.nextInt();
                int [] tab2 = new int[nb];
                System.out.println("Entrer les nombres:");
                for (int i = 0; i < nb; i++) {
                    tab2 [i] = sc.nextInt();
                }

                System.out.println("Les elements communs dans les tableaux sont:");
                CommonElementbetween.commonElement(tab1,tab2);
            }


            case 5->{
                System.out.println("Entrer la valeur de x et de y:");
                int oi = sc.nextInt();
                int of = sc.nextInt();
                SwapTwoMumbers.swapToNumber(oi,of);
            }


            case 6->{
                System.out.println("Entrer un nombre:");
                PrintFibonacci.fibonacciSeries();
            }

            case 7->{
                System.out.println("Entrer un nombre:");
                int qw = sc.nextInt();
                System.out.println("Le resutat est : " + SumEachDigit.getNumberSum(qw));
            }


            case 8->{
               System.out.println("Entrer un nombre:");
            int dc = sc.nextInt();
            Boolean ans = CheckGivenNumber.isPrimeNumber(dc);
                if (ans) {
                    System.out.println("C'est un nombre premier");
                }
                else{

                    System.out.println("Ce n'est pas un nombre premier");
            }
            }


            case 9-> {
                System.out.println("Entrer un nombre:");
                int aw = sc.nextInt();
                Boolean ans = ArmstrongNumberOrNot.isArmstrongNumber(aw);
                if (ans) System.out.println("C'est un armstrong number");
                else
                    System.out.println("Ce n'est pas un armstrong number");
            }


            case 10->{
                System.out.println("Entrer la valeur en binaire a convertir:");
                int ad = sc.nextInt();
                System.out.println("Son equivalent est: " + ConvertBinaryToDecimal.getDecimalFromBinary(ad));
            }

            }

        }

}
