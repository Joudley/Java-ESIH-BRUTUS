package core;

public class Cours {
    private int CoursID;
    private String nameCours;
    private String nameProf;

    public Cours( int CoursID, String nameCours, String nameProf) {
        this.CoursID = CoursID;
        this.nameCours = nameCours;
        this.nameProf = nameProf;
    }


    public Cours() {
    }
    public int getCoursID() {
        return CoursID;
    }

    public void setCoursID(int CoursID) {
        this.CoursID = CoursID;
    }

    public String getNameCours() {
        return nameCours;
    }

    public void setNameCours(String nameCours) {
        this.nameCours = nameCours;
    }


    public String getNameProf() {
        return nameProf;
    }

    public void setNameProf(String nameProf) {
        this.nameProf = nameProf;
    }
}
