package core;

public class Materials {
    private int MaterialsID;
    private String nameMaterials;


    public Materials(int MaterialsID, String nameMaterials) {
        this.MaterialsID = MaterialsID;
        this.nameMaterials = nameMaterials;
    }


    public Materials() {
    }
    public int getMaterialsID() {

        return MaterialsID;
    }

    public void setMaterialsID(int MaterialsID) {

        this.MaterialsID = MaterialsID;
    }

    public String getNameMaterials() {
        return nameMaterials;
    }

    public void setNameMaterials(String nameMaterials) {
        this.nameMaterials = nameMaterials;
    }

}
