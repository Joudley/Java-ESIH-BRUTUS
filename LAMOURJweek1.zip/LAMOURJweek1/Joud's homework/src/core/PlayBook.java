package core;

import core.view.Features;

public class PlayBook {

    public static void main(String[] args) {

        Cours dCours = new Cours(20, "Java", "Jack");

        Features.display(dCours.getNameCours());


        Materials eMaterials = new Materials(12, "Computer");

        Features.display(eMaterials.getNameMaterials());


    }
}
