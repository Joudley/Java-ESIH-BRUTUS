package core;

public class Display {
    public static void showanything(Object o){
        System.out.println(o);
    }
}
