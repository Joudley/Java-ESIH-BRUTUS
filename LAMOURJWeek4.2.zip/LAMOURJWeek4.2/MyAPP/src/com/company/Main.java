package com.company;

import core.Display;
import core.Utils;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)  {
       // Display.showanything(Utils.eval("2*4+2+8/2"));
       // Display.showanything();

        Scanner sc = new Scanner(System.in);
        System.out.println("Ce programme vous permet deffectuer pas mal de calcul ");
        System.out.println("---------------------------------------------------");
        System.out.println("Faites choix de ce que vous voudriez :");
        System.out.println("       1- Calcul d'une expression");
        System.out.println("       2-Calcul du perimetre d'un rectangle");
        System.out.println("       3- Calcul du perimetre d'un carre");
        System.out.println("       4- Calcul du perimetre d'un triangle");
        System.out.println("       5-Calcul de l'air d'un rectangle");
        System.out.println("       5-Calcul de l'air d'un carre");
        System.out.println("       5-Calcul de l'air d'un triangle");
        int choice = sc.nextInt();
        switch (choice){
            case 1 -> {
                System.out.println("entre");
                String chaine = sc.next();
               Display.showanything(Utils.eval(chaine));
            }
            case 2->{
                System.out.println("Entr la longeur et la largeur");
                float longeur = sc.nextFloat();
                float largeur = sc.nextFloat();
                Display.showanything(Utils.pmrect(longeur,largeur));
            }
            case 3->{
                System.out.println("Entre la mesure d'un cote");
                float ad = sc.nextFloat();
                Display.showanything(Utils.pmcarre(ad));
            }
            case 4->{
                System.out.println("Entrer les les cotes du triangle");
                float cote1 =sc.nextFloat();
                float cote2 = sc.nextFloat();
                float cote3 = sc.nextFloat();
                Display.showanything(Utils.pmtriangle(cote1,cote2,cote3));
            }
            case 5 -> {
                System.out.println("Entr la longeur et la largeur");
                float longeur = sc.nextFloat();
                float largeur = sc.nextFloat();
                Display.showanything(Utils.airrect(longeur,largeur));

            }
            case 6->{
                System.out.println("Entre la mesure d'un cote");
                float ad = sc.nextFloat();
                Display.showanything(Utils.aircarre(ad));
            }
            case 7->{
                System.out.println("Entre la base et la hauteur");
                float base = sc.nextFloat();
                float hauteur =sc.nextFloat();
                Display.showanything(Utils.airtriangle(base,hauteur));
            }

        }
    }

}
