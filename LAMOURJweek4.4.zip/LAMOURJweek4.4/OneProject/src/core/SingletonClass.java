package core;

public class SingletonClass {
    private static SingletonClass myObj;

    static{
        myObj = new SingletonClass();
    }

    private SingletonClass(){

    }

    public static SingletonClass getInstance(){
        return myObj;
    }

    public void testMe(){
        System.out.println("Ca marche!!!");
    }

}
