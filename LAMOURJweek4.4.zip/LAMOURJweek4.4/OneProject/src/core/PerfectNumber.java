package core;

public class PerfectNumber {
    public static boolean isPerfectNumber(int number){

        int temp = 0;
        for(int i=1;i<=number/2;i++){
            if(number%i == 0){
                temp += i;
            }
        }
        if(temp == number){
            System.out.println("C'est un nombre parfait");
            return true;
        } else {
            System.out.println("Ce n'est pas un nombre parfait");
            return false;
        }
    }

}
