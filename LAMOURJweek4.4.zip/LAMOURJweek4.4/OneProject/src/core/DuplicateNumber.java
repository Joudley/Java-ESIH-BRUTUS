package core;

import java.util.ArrayList;
import java.util.List;
public class DuplicateNumber {
    public static void findDuplicateNumber(List<Integer> numbers){

        for (int i = 0; i < numbers.size()-1; i++) {
            for (int j=i+1; j<numbers.size();j++){
                if (numbers.get(i)== numbers.get(j)) System.out.println(numbers.get(i) + " apparait plus d'une fois");
            }
        }
    }

}
