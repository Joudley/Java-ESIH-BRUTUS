package com.company;

import core.*;
import core.RepeatedWords;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {

    private static Object List;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ce programme vous permet d'effectuer plusiers sortes de choses ");
        System.out.println("---------------------------------------------------");
        System.out.println("---------------------------------------------------");
        System.out.println("Faites choix de ce que vous voudriez!!!");
        System.out.println("---------------------------------------------------");
        System.out.println("       1- How to reverse Singly Linked List?");
        System.out.println("---------------------------------------------------");
        System.out.println("       2- Find out duplicate number between 1 to N numbers");
        System.out.println("---------------------------------------------------");
        System.out.println("       3- Find out middle index where sum of both ends are equal");
        System.out.println("---------------------------------------------------");
        System.out.println("       4- Write a singleton class");
        System.out.println("---------------------------------------------------");
        System.out.println("       5- Write a program to reverse a string using recursive algorithm");
        System.out.println("---------------------------------------------------");
        System.out.println("       6- Write a program to reverse a number");
        System.out.println("---------------------------------------------------");
        System.out.println("       7- Write a program to convert decimal number to binary format");
        System.out.println("---------------------------------------------------");
        System.out.println("       8- Write a program to find perfect number or not");
        System.out.println("---------------------------------------------------");
        System.out.println("       9- Write a program to implement ArrayList");
        System.out.println("---------------------------------------------------");
        System.out.println("       10- Write a program to find maximum repeated words from a file");
        int choice = sc.nextInt();
        switch (choice) {
            case 1 -> {
                SinglyLinkedList<Integer> sl = new SinglyLinkedList<Integer>();
                System.out.println("Combien d'elements contient votre tableau:" );
                int nbre = sc.nextInt();
                System.out.println("Entrer les nombres:");
                for (int i = 0; i < nbre; i++) {
                    sl.add(sc.nextInt());
                }
                System.out.println();
                sl.traverse();
                System.out.println();
                sl.reverse();
                sl.traverse();
            }

            case 2 -> {
                java.util.List<Integer> numbers = new ArrayList<Integer>();
                System.out.println(" Entre le nombre d'elements");
                int ajt = sc.nextInt();
                System.out.println("Entre les nombres");
                for (int i = 1; i < ajt; i++) {
                    numbers.add(sc.nextInt());
                }
                //add duplicate number into the list
                DuplicateNumber dn = new DuplicateNumber();
                dn.findDuplicateNumber(numbers);
            }


        case 3 -> {
            System.out.println("Combien d'elements ");
            int count = sc.nextInt();
            int[] num = new int[count];
            System.out.println("Entrer les nombres");
            for (int i = 0; i < count; i++) {
                num[i] = sc.nextInt();
            }
            try {
                System.out.println("Commence a l'index 0, ajouter des element jusqu'a l'index "
                        +  MiddleIndex.findMiddleIndex(num) + " et");
                System.out.println("Ajouter le reste du nombre pour qu'il soit egal");
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }

        case 4 -> {
            SingletonClass ms = SingletonClass.getInstance();
            ms.testMe();
        }

        case 5 -> {
            System.out.println("Entrer une chaine de caracteres:");
            String toreverse = sc.next();
            System.out.println("L'inverse est: " + ReverseString.reverseString(toreverse));

        }

        case 6 -> {
            System.out.println("Entrer un nombre:");
            int nb = sc.nextInt();
            System.out.println("L'inverse de ce nombre est: " + ReverseNumber.reverseNumber(nb));
        }

        case 7 -> {
            System.out.println("Entrer le nombre a convertir:");
          int ac = sc.nextInt();
            System.out.println("Son equivalent est:" );
            ConvertDecimalToBinary.printBinaryFormat(ac);
        }

        case 8 -> {
            System.out.println("Entrer le nombre:");
            PerfectNumber ipn = new PerfectNumber();
            int nbr = sc.nextInt();
            System.out.println("C'est le nombre parfait: " + ipn.isPerfectNumber(nbr));
        }

        case 9 -> {
            ArrayList mal = new ArrayList();
            System.out.println("Entrer une valeur: ");
            int ajouter =1;
            do {
                mal.add(sc.nextInt());
                System.out.println("Entrer 1 pour ajouter un nombre ");
                ajouter = sc.nextInt();
            }while (ajouter == 1);

            for (int i = 0; i < mal.size(); i++) {
                System.out.print(mal.get(i) + " ");
            }

            System.out.println("\nChercher un element:");
            int qc = sc.nextInt();
            System.out.println("L'element a l'index " + qc  + " est : " + mal.get(qc));
            System.out.println("Liste du tableau: " + mal.size());
            System.out.println("Retirer un element:");
            System.out.println("L'element retire est :" + mal.remove(sc.nextInt()));
            for (int i = 0; i < mal.size(); i++) {
                System.out.print(mal.get(i) + " ");
            }
        }

            case 10 -> {
                System.out.println("Entrer l'emplacement du fichier.txt:");
                String ab = sc.next();
                RepeatedWords mdc = new RepeatedWords();
                Map<String, Integer> wordMap = mdc.getWordCount(ab);
                List<Map.Entry<String, Integer>> list = mdc.sortByValue(wordMap);
                int k= 0;
                for (Map.Entry<String, Integer> entry : list) {
                    k++;
                    if (k==5)break;
                    System.out.println(entry.getKey() + " ---> " + entry.getValue() + " fois");
                }

            }

        }
    }
}

