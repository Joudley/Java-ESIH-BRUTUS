package com.company;
import core.Primalite;
import core.Factorielle;
import core.PGCD;
import core.PPMC;
import core.RechercheDichotomique;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
            Scanner sc = new Scanner(System.in);
            System.out.println("Ce programme vous permet deffectuer pas mal de choses ");
            System.out.println("---------------------------------------------------");
            System.out.println("Faites choix de ce que vous voudriez :");
            System.out.println("       1- Primalite d'un nombre");
            System.out.println("       2-Factorielle d'un nombre");
            System.out.println("       3- Plus grand commun diviseur");
            System.out.println("       4- Plus petit multiple commun");
            System.out.println("       5-Recherche dichotomique");
            int choice = sc.nextInt();
            switch (choice){
                        case 1 -> {
                            Primalite.primalite();
                        }
                        case 2->{
                            Factorielle.factorielle();
                        }
                        case 3->{
                            System.out.println("Le PGCD est "+PGCD.pgcd());
                        }
                        case 4->{
                            System.out.println("le PPMC est "+PPMC.ppmc());
                        }
                        case 5 -> {
                            int[] tab = RechercheDichotomique.insertion();
                            int[] tb = RechercheDichotomique.TriCroissantParInsertion(tab);
                            Boolean reponse = RechercheDichotomique.rechercheDichotonique(tb);
                            if(reponse == true){
                                System.out.println("Ce nombre est dans le tableau");
                            }else{
                                System.out.println("Ce nombre n'est pas dans le tableau");
                            }

                        }

                    }

        }

}
