package core;

import java.util.Scanner;

public class Factorielle {
    public static void factorielle(){
        System.out.println("Entrez un entier: ");
        Scanner pr= new Scanner(System.in);
        int i, fact = 1;
        //le nombre dont on veut calculer la factorielle
        int number = pr.nextInt();
        for(i=1; i <= number; i++){
            fact = fact * i;
        }
        System.out.println("La factorielle de "+number+" est: "+fact);
    }
}
