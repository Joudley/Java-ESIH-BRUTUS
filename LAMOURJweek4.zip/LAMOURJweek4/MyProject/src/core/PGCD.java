package core;

import java.util.Scanner;

public class PGCD {

    public static int pgcd() {
        int[] tab = RechercheDichotomique.insertion();
        int[] tb = RechercheDichotomique.TriCroissantParInsertion(tab);
        int reponse =1;
        for (int i = 2;i<= tb[tab.length-1]/2 ; i++){
            reponse = tb[0]/i;
            for (int j= 0;j< tb.length;j++){
                if(tb[j]%reponse!=0) j = tb.length;
                if (j == tb.length-1 && tab[j]%reponse ==0)return reponse;
            }
        }
        return reponse;
}
}
