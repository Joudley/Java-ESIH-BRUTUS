package core;

import java.util.Scanner;

public class PPMC {

   public static int ppmc(){
       int[] tab = RechercheDichotomique.insertion();
       int[] tb = RechercheDichotomique.TriCroissantParInsertion(tab);
       int reponse;
       for (int i = 1;;i++){
           reponse = tb[tb.length-1]*i;
           for (int j= 0;j< tb.length;j++){
               if(reponse%tb[j]!=0) j = tb.length;
               if (j == tb.length-1 && reponse%tab[j] ==0)return reponse;
           }
       }
    }
}
