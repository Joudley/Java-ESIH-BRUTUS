package core;

import java.util.Scanner;

public class RechercheDichotomique {
    public static int[] insertion(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Entrez le nombre d'elements");
        int nombre = sc.nextInt();
        System.out.println("Entrez les elements");
        int[] tab = new int[nombre];
        for (int i = 0; i < nombre; i++){
            tab[i] = sc.nextInt();
        }
        return tab;
    }
    // Tri insertion
    public static int[] TriCroissantParInsertion(int[] tab){
        int x,j;
        for (int i = 1; i< tab.length; i++){
            x = tab[i];
            j = i-1;
            while (j>=0 && x<tab[j]){
                tab[j+1]=tab[j];
                j=j-1;
            }
            tab[j+1]= x;
        }
        return tab;
    }
    // methodes dichotoniques
    public static boolean rechercheDichotonique(int[] tab){
        Scanner sc = new Scanner(System.in);
        System.out.println("Entre le nombre a rechercher");
        int nb = sc.nextInt();
        int inf = 0;
        int sup = tab.length-1;
        int middle = (inf + sup)/2;
        Boolean find = false;
        while ( find==false && inf<=sup){
            if (tab[middle] == nb){
                find = true;
            }else{
                if (nb<tab[middle]){
                    sup = middle - 1;
                }else {
                    inf = middle + 1;
                }
            }
            middle = (inf + sup)/2;
        }
        return find;
    }



}

