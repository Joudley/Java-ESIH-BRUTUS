package core;

import java.util.Scanner;

public class Primalite {

    public static void primalite() {
        System.out.println("Entrez un entier: ");
        Scanner pr= new Scanner(System.in);
        int rst;
        boolean choice = true;
        int number = pr.nextInt();

        for(int i=2; i <= number/2; i++) {
            //nombre est divisible par lui-meme
            rst = number%i;

            //si le rst est 0, alors arrete la boucle. Sinon continuer la boucle
            if(rst == 0) {
                choice = false;
                break;
            }
        }
        //Resultat: premier si choise est vrai sinon n'est pas premier
        if(choice)
            System.out.println(number + " est un nombre premier");
        else
            System.out.println(number + " n'est pas un nombre premier");
    }
}
