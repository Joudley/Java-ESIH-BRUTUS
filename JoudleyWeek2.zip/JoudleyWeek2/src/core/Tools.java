package core;

import java.util.Scanner;

public class Tools {
    public static int[] insertion(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Combien d'element contient votre tableau");
        int nombre = sc.nextInt();
        System.out.println("Entre les elements");
        int[] tab = new int[nombre];
        for (int i = 0; i < nombre; i++){
            tab[i] = sc.nextInt();
        }
        return tab;
    }
    // Tri a bulles
    public static int[] triCroissantABulle(int[] tab){
        int temporaire = 1;
        int x;
        while (temporaire == 1){
            temporaire = 0;
            for (int i= 0; i< tab.length-1;i++){
                if (tab[i]>tab[i+1]){
                    temporaire = 1;
                    x = tab[i];
                    tab[i] = tab[i+1];
                    tab[i+1] = x;
                }
            }
        }
        return tab;
    }

    public static int[] triDecroissantABulle(int[] tab){
        int temporaire = 1;
        int x;
        while (temporaire == 1){
            temporaire = 0;
            for (int i= 0; i< tab.length-1;i++){
                if (tab[i]<tab[i+1]){
                    temporaire = 1;
                    x = tab[i];
                    tab[i] = tab[i+1];
                    tab[i+1] = x;
                }
            }
        }
        return tab;
    }

    // Tri par transposition
    public static int[] triCroissantParTransposer(int[] tab){
        for (int i = 0 ; i< tab.length-1; i++){
            int x;
            int j;
            if (tab[i]>tab[i+1]){
                x = tab[i];
                tab[i]=tab[i+1];
                tab[i+1]= x;
                j = i-1;
                while (j>=0){
                    if (tab[j]>tab[j+1]){
                        x = tab[j];
                        tab[j]= tab[j+1];
                        tab[j+1]= x;
                        j=j-1;
                    }else {
                        j=-1;
                    }
                }
            }
        }
        return tab;
    }

    public static int[] triDecroissantParTransposer(int[] tab){
        for (int i = 0 ; i< tab.length-1; i++){
            int x;
            int j;
            if (tab[i]<tab[i+1]){
                x = tab[i];
                tab[i]=tab[i+1];
                tab[i+1]= x;
                j = i-1;
                while (j>=0){
                    if (tab[j]<tab[j+1]){
                        x = tab[j];
                        tab[j]= tab[j+1];
                        tab[j+1]= x;
                        j=j-1;
                    }else {
                        j=-1;
                    }
                }
            }
        }
        return tab;
    }


    // Tri par recherche du minimum
    public static int[] triCroissantParRechercheMininimal(int[] tab){
        int k,m;
        for (int i =0; i< tab.length-1; i++){
            m = tab[i];
            k = i;
            for (int j = i+1; j< tab.length;j++){
                if (m>tab[j]){
                    m = tab[j];
                    k =j;
                }
            }
            tab[k]= tab[i];
            tab[i]=m;
        }
        return tab;
    }

    public static int[] triDecroissantParRechercheMinimal(int[] tab){
        int k,m;
        for (int i =0; i< tab.length-1; i++){
            m = tab[i];
            k = i;
            for (int j = i+1; j< tab.length;j++){
                if (m<tab[j]){
                    m = tab[j];
                    k =j;
                }
            }
            tab[k]= tab[i];
            tab[i]=m;
        }
        return tab;
    }


    // Tri insertion
    public static int[] triCroissantParInsertion(int[] tab){
        int x,j;
        for (int i = 1; i< tab.length; i++){
            x = tab[i];
            j = i-1;
            while (j>=0 && x<tab[j]){
                tab[j+1]=tab[j];
                j=j-1;
            }
            tab[j+1]= x;
        }
        return tab;
    }


    public static int[] triDecroissantParInsertion(int[] tab){
        int x,j;
        for (int i = 1; i< tab.length; i++){
            x = tab[i];
            j = i-1;
            while (j>=0 && x>tab[j]){
                tab[j+1]=tab[j];
                j=j-1;
            }
            tab[j+1]= x;
        }
        return tab;
    }

    // Les methodes de Recherches

    // Recherche lineaire
    public static boolean rechercheLineaire(int[] tab, int nb){
        Boolean find = false;
        for(int i = 0 ; i < tab.length; i++){
            if (tab[i]==nb){
                find = true;
                break;
            }else{
                find =false;
            }
        }
        return find;
    }

    // methodes dichotoniques
    public static boolean rechercheDichotonique(int[] tab, int nb){
        int inf = 0;
        int sup = tab.length-1;
        int middle = (inf + sup)/2;
        Boolean find = false;
        while ( find==false && inf<=sup){
            if (tab[middle] == nb){
                find = true;
            }else{
                if (nb<tab[middle]){
                    sup = middle - 1;
                }else {
                    inf = middle + 1;
                }
            }
            middle = (inf + sup)/2;
        }
        return find;
    }

    public static Boolean rechercheTernaire(int[] tab, int inf, int sup, int nb)
    {
        if (sup >= inf)
        {
            int mid1 = inf + (sup - inf)/3;
            int mid2 = mid1 + (sup - inf)/3;

            if (tab[mid1] == nb) return true;

            if (tab[mid2] == nb) return true;

            if (tab[mid1] > nb) return rechercheTernaire(tab, inf, mid1-1, nb);

            if (tab[mid2] < nb) return rechercheTernaire(tab, mid2+1, sup, nb);

            return rechercheTernaire(tab, mid1+1, mid2-1, nb);
        }

        return false;
    }

    public static Boolean rechercheParInterpolation(int tab[], int inf, int sup, int nb)
    {
        int pos;

        if (inf <= sup && nb >= tab[inf] && nb <= tab[sup]) {

            pos = inf
                    + (((sup - inf) / (tab[sup] - tab[inf]))
                    * (nb - tab[inf]));

            if (tab[pos] == nb)
                return true;

            if (tab[pos] < nb)
                return rechercheParInterpolation(tab, pos + 1, sup,
                        nb);

            if (tab[pos] > nb)
                return rechercheParInterpolation(tab, inf, pos - 1,
                        nb);
        }
        return false;
    }
}
