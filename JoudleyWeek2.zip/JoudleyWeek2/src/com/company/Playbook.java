package com.company;
import core.Tools;

import java.util.Arrays;
import java.util.Scanner;

public class Playbook {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Programme de Tri et de Recherche.");
        System.out.println("---------------------------------------------------");
        int[] tab = Tools.insertion();
        System.out.println("Trier un Tabbleau :");
        System.out.println("       1- Odre Croissant");
        System.out.println("       2-Odre Decroissant");
        System.out.println("       3- Rechercher element");
        int choice = sc.nextInt();
        switch (choice){
            case 1 -> {
                System.out.println("    1- Tri a Bulles");
                System.out.println("    2- Tri par Transposer");
                System.out.println("    3- Par recherche Minimum");
                System.out.println("    4- Par insertion ");
                int nb = sc.nextInt();
                switch (nb){
                    case 1->{
                        int[] tab1 = Tools.triCroissantABulle(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                    case 2->{
                        int[] tab1 = Tools.triCroissantParTransposer(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                    case 3->{
                        int[] tab1 = Tools.triCroissantParRechercheMininimal(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                    case 4->{
                        int[] tab1 = Tools.triCroissantParInsertion(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                }
            }
            case 2->{
                System.out.println("    1- Tri a Bulles");
                System.out.println("    2- Tri par Transposer");
                System.out.println("    3- Par recherche Minimum");
                System.out.println("    4- Par insertion ");
                int nb = sc.nextInt();
                switch (nb){
                    case 1->{
                        int[] tab1 = Tools.triDecroissantABulle(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                    case 2->{
                        int[] tab1 = Tools.triDecroissantParTransposer(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                    case 3->{
                        int[] tab1 = Tools.triDecroissantParRechercheMinimal(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                    case 4->{
                        int[] tab1 = Tools.triDecroissantParInsertion(tab);
                        System.out.println(Arrays.toString(tab1));
                    }
                }

            }
            case 3 ->{
                System.out.println("Methode de Recherche");
                System.out.println("        1- Methode Lineaire");
                System.out.println("        2- Methode binaire");
                System.out.println("        3- Methode tenaire");
                System.out.println("        4- Methode d'interpolation");
                System.out.println("----------------------------------------------");
                int nb = sc.nextInt();
                switch (nb) {
                    case 1 -> {
                        System.out.println("            Nombre a rechercher");
                        int number = sc.nextInt();
                        int[] tab1 = Tools.triCroissantABulle(tab);
                        Boolean test = Tools.rechercheLineaire(tab1, number);
                        System.out.println(test);
                    }

                    case 2 -> {
                        System.out.println("            Nombre a Rechercher");
                        int number = sc.nextInt();
                        int[] tab1 = Tools.triCroissantABulle(tab);
                        Boolean test = Tools.rechercheDichotonique(tab1, number);
                        System.out.println(test);
                    }
                    case 3 ->{
                        System.out.println("            Nombre a Rechercher");
                        int number = sc.nextInt();
                        int[] tab1 = Tools.triCroissantABulle(tab);
                        Boolean test = Tools.rechercheTernaire(tab1,0, tab.length-1,number);
                        System.out.println(test);
                    }
                    case 4 ->{
                        System.out.println("            Nombre a Rechercher");
                        int number = sc.nextInt();
                        int[] tab1 = Tools.triCroissantABulle(tab);
                        Boolean test = Tools.rechercheParInterpolation(tab1,0, tab.length-1, number);
                        System.out.println(test);
                    }
                }
            }
        }
    }
}
